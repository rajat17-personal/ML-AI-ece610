python autograder.py -t test_cases/q8/2-ExactFull
python autograder.py -t test_cases/q11/6-ParticlePredict
python autograder.py -t test_cases/q7/1-ExactPredict
