# visualizebn.py
from pacman import layout, GameState
from inference import constructBayesNet
from graphviz import Digraph

# 1) Load a standard layout (pick any .lay under layouts/, e.g. 'smallClassic.lay')
layout = layout('smallClassic.lay')

# 2) Create & initialize a fresh GameState
gameState = GameState()
gameState.initialize(layout)

# 3) Build your Bayes-net
bn, observedVars = constructBayesNet(gameState)

# 4) Render as before
dot = Digraph(comment='Ghost-Tracking Bayes Net')
dot.attr(rankdir='LR')
for v in bn.getVariables():
    dot.node(v, v)
for p, c in bn.getEdges():
    dot.edge(p, c)
dot.render('ghost_tracking_net', format='png', cleanup=True)
print("Wrote ghost_tracking_net.png")